public class Couleur {
    private final String nom;
    private final char abreviation;

    public Couleur(String unNom, char uneAbreviation){
        this.nom = unNom;
        this.abreviation = uneAbreviation;
    }

    public String getNom() {
        return nom;
    }

    public char getAbreviation() {
        return abreviation;
    }

    public boolean equals(Couleur uneCouleur){
        if (uneCouleur instanceof Couleur){
            if(this.getNom().equals(uneCouleur.getNom())){
                return true;
            }else {
                return false;
            }
        }else {
            return false;
        }
    }

    @Override
    public String toString() {
        return Character.toString(abreviation)+ " ";
    }
}
