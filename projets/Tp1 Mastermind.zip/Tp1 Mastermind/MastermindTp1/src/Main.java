import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //partie du code permmettant au joueur de quiter le progamme ou de commencer une nouvelle partie avec une boucle while pour gérer les cas d'erreur dans le input
        var quitter = false;
        var scanner = new Scanner(System.in);
        while (!quitter){
            System.out.println("Entrer le numéro de l'option désiré pour poursuivre.\n1 - Nouvelle partie\n2 - quitter");
            var choixMenuPrincipal = scanner.nextLine().toLowerCase();
            while (!(choixMenuPrincipal.contains("1")||choixMenuPrincipal.contains("2"))||choixMenuPrincipal.length()!=1) {
                if (choixMenuPrincipal.length() != 1) {
                    System.out.println("Erreur. La serie entrer ne contient pas 1 caractères. Entrer un seul caractère.");
                    choixMenuPrincipal = scanner.nextLine().toLowerCase();
                } else if (!(choixMenuPrincipal.contains("1") || choixMenuPrincipal.contains("2"))) {
                    System.out.println("Erreur, le caractère choisi ne fait pas partie des options. Entrer seulement l'une des options valide\n" +
                            "Les options valide sont : 1 - Nouvelle partie     2 - quitter");
                    choixMenuPrincipal = scanner.nextLine().toLowerCase();
                }
            }
            if (choixMenuPrincipal.contains("1")){
                System.out.println("Entrer le numéro de l'option désiré pour créer la solution.\n1 - Choisir une solution\n2 - Générer une solution aléatoire");

                //partie du code permmettant au joueur de chosir s'il veut un code solution alétoire ou choisi manuellement avec une boucle while pour gérer les cas d'erreur dans le input
                var choixGenerationSolution = scanner.nextLine().toLowerCase();
                while (!(choixGenerationSolution.contains("1")||choixGenerationSolution.contains("2"))||choixGenerationSolution.length()!=1) {
                    if (choixGenerationSolution.length() != 1) {
                        System.out.println("Erreur. La serie entrer ne contient pas 1 caractères. Entrer un seul caractère.");
                        choixGenerationSolution = scanner.nextLine().toLowerCase();
                    } else if (!(choixGenerationSolution.contains("1") || choixGenerationSolution.contains("2"))) {
                        System.out.println("Erreur, le caractère choisi ne fait pas partie des options. Entrer seulement l'une des options valide\n" +
                                "Les options valide sont : 1 - Nouvelle partie     2 - quitter");
                        choixGenerationSolution = scanner.nextLine().toLowerCase();
                    }
                }
                //code dans lecas ou le joueur choisi de manuellement créer le code solution
                if (choixGenerationSolution.contains("1")){
                    System.out.println("**** CHOIX DU CODE SECRTET ****\n" +
                            "La solution comprend 5 couleurs.Pour choisir une couleur entrer la première lettre de la couleur.\n" +
                            "Les couleurs disponible sont les suivante :\n" +
                            "B - bleu     R - rouge     O - orange    T - turquoise\n" +
                            "J - jaune    V - vert      G - gris      N - noir\n");
                    Serie solution = new Serie();
                    Mastermind solutionChoisi =new Mastermind(detectionCouleur(solution));
                    jeu(solutionChoisi);
                    //code dans le cas ou le joueur choisi de créer aléatoirement le code solution
                }else{
                    Mastermind solutionAleatoire = new Mastermind();
                    jeu(solutionAleatoire);
                }
            } else {
                System.out.println("Au revoir!");
                quitter = true;
            }
        }
    }

    //méthode permettant d'ajouter les 5 couleur d'une série à l'aide de l'input de l'utilisateur avec une boucle while pour gérer les cas d'erreur dans le input
    public static Serie detectionCouleur(Serie uneSerie){
        Couleur bleu = new Couleur("bleu",'B');
        Couleur rouge = new Couleur("rouge",'R');
        Couleur orange = new Couleur("orange",'O');
        Couleur jaune = new Couleur("jaune",'J');
        Couleur vert = new Couleur("vert",'V');
        Couleur gris = new Couleur("gris",'G');
        Couleur noir = new Couleur("noir",'N');
        Couleur turquoise = new Couleur("turquoise",'T');
        var scanner = new Scanner(System.in);

        var unString = scanner.nextLine().toLowerCase();

        while (!(unString.contains("b")||unString.contains("r")||unString.contains("o")||unString.contains("j")||unString.contains("v")||unString.contains("g")||unString.contains("n")||unString.contains("t"))||unString.length()!= 5) {
            if (unString.length() != 5) {
                System.out.println("Erreur. La serie entrer ne contient pas 5 caractères. Entrer une série contenant exactement 5 caractère.\nExemple : bgrto");
                unString = scanner.nextLine().toLowerCase();
            } else if (!(unString.contains("b") || unString.contains("r") || unString.contains("o") || unString.contains("j") || unString.contains("v") || unString.contains("g") || unString.contains("n") || unString.contains("t"))) {
                System.out.println("Erreur, l'un des caractères choisi ne fait pas parti des options. Entrer seulement des options valide.\n" +
                        "Les couleurs disponible sont les suivante :\n" +
                        "B - bleu     R - rouge     O - orange    T - turquoise\n" +
                        "J - jaune    V - vert      G - gris      N - noir\n");
                unString = scanner.nextLine().toLowerCase();
            }
        }
        for (int i = 0; i < 5;i++){
            char caractere = unString.charAt(i);
            if (caractere == 'b'){
                uneSerie.ajouterCouleur(bleu);
            } else if (caractere == 'r'){
                uneSerie.ajouterCouleur(rouge);
            } else if (caractere == 'o'){
                uneSerie.ajouterCouleur(orange);
            } else if (caractere == 'j'){
                uneSerie.ajouterCouleur(jaune);
            } else if (caractere == 'v'){
                uneSerie.ajouterCouleur(vert);
            } else if (caractere == 'g'){
                uneSerie.ajouterCouleur(gris);
            } else if (caractere == 'n'){
                uneSerie.ajouterCouleur(noir);
            } else if (caractere == 't'){
                uneSerie.ajouterCouleur(turquoise);
            }
        }
        return uneSerie;
    }

    //méthode qui s'ocuppe de faire les ouze essai si besoin et de déterminer si le joueur est victorieux ou non
    public static void jeu(Mastermind unMastermind){
        boolean victoire =false;
        while (unMastermind.getNbEssais()<12 && !victoire){
            System.out.println("**** ESSAIS #"+ (unMastermind.getNbEssais()+1) +"/12 ****\n" +
                    "La solution comprend 5 couleurs. Pour choisir une couleur entrer la première lettre de la couleur choisi.\n" +
                    "Les couleurs disponible sont les suivante :\n" +
                    "B - bleu     R - rouge     O - orange    T - turquoise\n" +
                    "J - jaune    V - vert      G - gris      N - noir\n");
            Serie unEssais = new Serie();
            unMastermind.essayer(detectionCouleur(unEssais));
            if (unEssais.equals(unMastermind.getSolution())){
                victoire=true;
            } else{
                System.out.println(unMastermind.toString());
                //System.out.println(unMastermind.getSolution());
            }
        } if (unMastermind.getNbEssais()<=12){
            System.out.println(unMastermind.getSolution());
            System.out.println("Victoire");

        }else {
            System.out.println(unMastermind.getSolution());
            System.out.println("Game Over");
        }
    }
}
