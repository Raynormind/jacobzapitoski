import java.util.ArrayList;

public class Mastermind  {
    private Serie solution;
    private ArrayList<Serie> series;

    public Mastermind(Serie uneSolution){
        this.solution = uneSolution;
        this.series = new ArrayList<>();
    }
    public Mastermind(){
        ArrayList<Couleur> listeCouleur= new ArrayList<Couleur>();
        listeCouleur.add(new Couleur("bleu",'B'));
        listeCouleur.add(new Couleur("rouge",'R'));
        listeCouleur.add(new Couleur("orange",'O'));
        listeCouleur.add(new Couleur("jaune",'J'));
        listeCouleur.add(new Couleur("vert",'V'));
        listeCouleur.add(new Couleur("gris",'G'));
        listeCouleur.add(new Couleur("noir",'N'));
        listeCouleur.add(new Couleur("turquoise",'T'));
        this.solution = new Serie();
        for (int i = 0; i < 5 ;i++){
        solution.ajouterCouleur(listeCouleur.get((int)(Math.random() * listeCouleur.size())));
        }
        this.series = new ArrayList<>();
    }

    public Serie getSolution() {
        return solution;
    }

    public int getNbEssais(){
        return this.series.size();
    }
    //ajoute laserie en paramètre dans le array serie pourfaire marcher la méthode toString de la classe
    public Serie essayer(Serie uneSerie){
        this.series.add(uneSerie);
        if (uneSerie.equals(this.solution)){
            return solution;
        }else {
            return this.solution.comparer(uneSerie);
        }
    }

    public String toString() {
        String listeEssais = "";
        for (int i = 0; i < this.getNbEssais(); i++){
            listeEssais = listeEssais.concat(this.series.get(i).toString()+"| "+ this.solution.comparer(this.series.get(i)).toString()+"\n");
        }
        return listeEssais;
    }
}
