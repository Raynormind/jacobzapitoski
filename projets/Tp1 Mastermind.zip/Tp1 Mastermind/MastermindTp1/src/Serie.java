import java.util.ArrayList;

public class Serie {
    private ArrayList<Couleur> couleurs;

    public Serie(){
        this.couleurs = new ArrayList<>();
    }

    public Couleur getCouleur(int position){
        try{
            if (position <= this.couleurs.size()){
                return this.couleurs.get(position);
            }else {
                throw new IllegalArgumentException();
            }
        }catch (IllegalArgumentException e){
        }
        return null;
    }

    public void ajouterCouleur(Couleur uneCouleur){
        this.couleurs.add(uneCouleur);
    }

    public boolean equals(Serie uneSerie){
        if (uneSerie instanceof Serie){
            for (int i = 0; i < this.couleurs.size() ;i++){
                if(this.getCouleur(i).equals(uneSerie.getCouleur(i))){
                }else {
                    return false;
                }
            }
            return true;
        }else {
            return false;
        }
    }

    public Serie comparer(Serie uneSerie){
        Serie retour = new Serie();
        Couleur noir = new Couleur("noir",'N');
        Couleur blanc = new Couleur("blanc",'B');

        try {
            if (this.couleurs.size() != uneSerie.couleurs.size()){
                throw new IllegalArgumentException();
            }else{
                //permet d'afficher les N avant les B
                for (int i = 0; i < this.couleurs.size(); i++) {
                    //Détecte les couleurs identiques au bon endroit
                    if (this.getCouleur(i).equals(uneSerie.getCouleur(i))) {
                        retour.ajouterCouleur(noir);
                    }
                }
                for (int i = 0; i < this.couleurs.size(); i++) {
                    //Détecte les couleurs identiques au bon endroit
                    if (this.getCouleur(i).equals(uneSerie.getCouleur(i))) {
                    }else {
                        //manque un moyen de compter les duplication des deuxserie sans les détruire afin de faire un si (la quantite delement specifique d'uneSerie > this a quantite delement specifique)
                        //
                        //Détecte les couleurs identiques à des endroits différents
                        for (int j = 0; j < this.couleurs.size(); j++) {
                            if (i != j && uneSerie.getCouleur(i).equals(this.getCouleur(j))) {
                                j = uneSerie.couleurs.size();
                                retour.ajouterCouleur(blanc);
                            }
                        }
                    }
                }
            }
        }catch (IllegalArgumentException e){

        }
        return retour;
    }

    public String toString() {
        String liste = "";
        for (int i = 0; i < this.couleurs.size() ;i++){
           liste = liste.concat(this.getCouleur(i).toString());
        }
        return liste;
    }
}
